import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ConfigService } from '@nestjs/config';
import { config as aswConfig } from 'aws-sdk';
import { initSwagger, setupCors, setupPipes, initAws } from './server';
import { Logger } from '@nestjs/common';
async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const config = app.get(ConfigService);

  setupPipes(app, config);

  initAws(aswConfig);
  initSwagger(app);
  setupCors(app);

  const port = config.get('port') ?? 3050;

  await app.listen(port, () => {
    Logger.log('🚀 API Listening on port', port);
  });
}

bootstrap();
