import {
  IsEmail,
  IsNotEmpty,
  IsString,
  IsOptional,
  Validate,
} from 'class-validator';
import { IsStringArray } from '../../common/validators';

import { CONSTS } from '../../common/constants/';
import { ApiProperty } from '@nestjs/swagger';
const { ADDITIONAL_FEATURE, PROGRAMS } = CONSTS;

export class TenantDto {
  @ApiProperty({
    example: 'State',
    description: 'Type',
  })
  @IsNotEmpty()
  type: string;

  @ApiProperty({
    example: 'description',
    description: 'Description',
  })
  @IsOptional()
  description: string;

  @ApiProperty({
    example: 'Name',
    description: 'Name',
  })
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    example: 'abc@yopmail.com',
    description: 'Email Id',
  })
  @IsNotEmpty()
  @IsEmail()
  email: string;

  @ApiProperty({
    example: '+15555555555',
    description: 'Contact Number',
  })
  @IsNotEmpty()
  contactNumber: number;

  @ApiProperty({
    example: 'xyz',
    description: 'Address',
  })
  @IsNotEmpty()
  address: string;

  @ApiProperty({
    example: 'state',
    description: 'State',
  })
  @IsNotEmpty()
  state: string;

  @ApiProperty({
    example: 'city',
    description: 'city',
  })
  @IsNotEmpty()
  city: string;

  @ApiProperty({
    example: '123',
    description: 'zipCode',
  })
  @IsNotEmpty()
  zipCode: number;

  @ApiProperty({
    example: 'est',
    description: 'timeZone',
  })
  @IsNotEmpty()
  timeZone: string;

  @ApiProperty({
    example: 'domainName',
    description: 'domainName',
  })
  @IsNotEmpty()
  domainName: string;

  @ApiProperty({
    example: 'abc',
    description: 'databaseName',
  })
  @IsNotEmpty()
  databaseName: string;

  @ApiProperty({
    example: 'clientLogo',
    description: 'clientLogo',

    type: 'string',
    format: 'binary',
    required: false,
  })
  @IsString()
  @IsOptional()
  clientLogo: string;

  @ApiProperty({
    example: 'green',
    description: 'accentColor',
  })
  @IsNotEmpty()
  accentColor: string;

  @ApiProperty({
    example: 'Curriculum',
    description: 'Curriculum',
  })
  @IsString()
  @IsOptional()
  programs: string;

  @ApiProperty({
    example: 'Life Skills',
    description: 'Life Skills',
  })
  @IsString()
  @IsOptional()
  additionalFeature: string;

  @ApiProperty({
    example: 'StateRegion',
    description: 'stateRegion',
  })
  @IsString()
  stateRegion: string;
}

export interface SearchDto {
  query: string;
}

export interface DomainNameWithIdDto {
  query: string;
  id: string;
}

export class EditTenantDto {
  @ApiProperty({
    example: 'State',
    description: 'Type',
    required: false,
  })
  @IsString()
  @IsOptional()
  type: string;

  @ApiProperty({
    example: 'description',
    description: 'Description',
    required: false,
  })
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({
    example: 'name',
    description: 'Name',
    required: false,
  })
  @IsString()
  @IsOptional()
  name: string;

  @ApiProperty({
    example: 'abc@yopmail.com',
    description: 'Email',
    required: false,
  })
  @IsString()
  @IsOptional()
  @IsEmail()
  email: string;

  @ApiProperty({
    example: '+15555555555',
    description: 'Contact Number',
    required: false,
  })
  @IsOptional()
  contactNumber: number;

  @ApiProperty({
    example: 'xyz',
    description: 'Address',
    required: false,
  })
  @IsString()
  @IsOptional()
  address: string;

  @ApiProperty({
    example: 'state',
    description: 'State',
    required: false,
  })
  @IsString()
  @IsOptional()
  state: string;

  @ApiProperty({
    example: 'city',
    description: 'City',
    required: false,
  })
  @IsString()
  @IsOptional()
  city: string;

  @ApiProperty({
    example: '123',
    description: 'ZipCode',
    required: false,
  })
  @IsOptional()
  zipCode: number;

  @ApiProperty({
    example: 'timeZone',
    description: 'TimeZone',
    required: false,
  })
  @IsString()
  @IsOptional()
  timeZone: string;

  @ApiProperty({
    example: 'axz',
    description: 'DomainName',
    required: false,
  })
  @IsString()
  @IsOptional()
  domainName: string;

  @ApiProperty({
    example: 'abc',
    description: 'databaseName',
    required: false,
  })
  @IsString()
  @IsOptional()
  databaseName: string;

  @ApiProperty({
    example: 'clientLogo',
    description: 'clientLogo',

    type: 'string',
    format: 'binary',
    required: false,
  })
  @IsString()
  @IsOptional()
  clientLogo: string;

  @ApiProperty({
    example: 'green',
    description: 'accentColor',
    required: false,
  })
  @IsString()
  @IsOptional()
  accentColor: string;

  @ApiProperty({
    example: 'Curriculum',
    description: 'Curriculum',
    required: false,
  })
  @IsOptional()
  programs: string;

  @ApiProperty({
    example: 'Life Skills',
    description: 'Life Skills',
    required: false,
  })
  @IsOptional()
  additionalFeature: string;

  @ApiProperty({
    example: true,
    description: 'isArchive',
    required: false,
  })
  @IsOptional()
  isArchive: boolean;

  @ApiProperty({
    example: false,
    description: 'isDelete',
    required: false,
  })
  @IsOptional()
  isDelete: boolean;

  @IsOptional()
  stateRegion: string;
}
