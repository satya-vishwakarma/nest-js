import { idDto } from './../common/dtos/query.dto';
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  Put,
  Delete,
  UploadedFile,
  UseInterceptors,
  UseGuards,
} from '@nestjs/common';
import { TenantService } from './tenant.service';
import {
  DomainNameWithIdDto,
  EditTenantDto,
  SearchDto,
  TenantDto,
} from './dto/add-tenant.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { AuthGuard } from '../auth/guards/auth.guard';
import {
  ApiBearerAuth,
  ApiConsumes,
  ApiParam,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';

@ApiBearerAuth()
@ApiTags('Tenants')
@UseGuards(AuthGuard)
@Controller('tenants')
export class TenantController {
  constructor(private readonly tenantService: TenantService) {}

  /**
   * Getting tenant list
   *
   * @returns Object
   */
  @Get()
  tenantList() {
    return this.tenantService.tenantList();
  }

  /**
   * Saving tenants
   *
   * @param tenantDto Object
   * @returns Object
   */
  @ApiConsumes('multipart/form-data')
  @Post()
  @UseInterceptors(FileInterceptor('clientLogo'))
  async saveTenant(@UploadedFile() file, @Body() tenantDto: TenantDto) {
    try {
      return await this.tenantService.saveTenant(file, tenantDto);
    } catch (error) {
      throw error;
    }
  }

  @Get('check-domain-name')
  checkDomainNameExists(@Query() { query, id }: DomainNameWithIdDto) {
    return this.tenantService.checkDomainNameExists(query, id);
  }

  /**
   * Search
   *
   * @param param Object
   * @returns Object
   */
  @Get('search')
  @ApiQuery({ name: 'query', example: 'abc' })
  search(@Query() { query }: SearchDto) {
    return this.tenantService.findInAllColumn(query);
  }

  /**
   * Get archive list
   */
  @Get('/getArchive')
  getArchive() {
    return this.tenantService.getArchiveList();
  }

  /**
   * Search archive
   *
   * @param param string
   * @returns object
   */
  @ApiQuery({ name: 'query', example: 'abc' })
  @Get('/searchArchive')
  searchArchive(@Query() { query }: SearchDto) {
    return this.tenantService.searchArchive(query);
  }

  /**
   * Update tenant by Object id
   *
   * @param param Object
   * @param body  Object
   * @returns Object
   */
  @Put(':id')
  @ApiParam({ example: '594ced02ed345b2b049222c5', name: 'id' })
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('clientLogo'))
  updateById(
    @Param() { id }: idDto,
    @UploadedFile() file,
    @Body() body: EditTenantDto,
  ) {
    return this.tenantService.updateTenants(id, file, body);
  }

  @Get('get-programs')
  getPrograms() {
    return this.tenantService.getPrograms();
  }

  @Get('get-additional-feature')
  getAdditionalFeature() {
    return this.tenantService.getAdditionalFeature();
  }

  /**
   * Get  tenant by id
   * @param param Object
   * @returns Object
   */
  @Get(':id')
  @ApiParam({ example: '594ced02ed345b2b049222c5', name: 'id' })
  findById(@Param() { id }: idDto) {
    return this.tenantService.findById(id);
  }

  /**
   * Delete tenant
   *
   * @param param  Object
   * @returns Object
   */
  @Delete(':id')
  @ApiParam({ example: '594ced02ed345b2b049222c5', name: 'id' })
  removeById(@Param() { id }: idDto) {
    return this.tenantService.removeById(id);
  }
}
