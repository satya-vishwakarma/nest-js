export enum userStatus {
  ACTIVE = 1,
  DELETED = 0,
  REGISTER = 2,
}
