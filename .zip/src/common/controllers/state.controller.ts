import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { StateService } from '../services/state.service';
import { idDto } from '../dtos/query.dto';
import { AuthGuard } from '../../auth/guards/auth.guard';
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger';

@ApiTags('State')
@UseGuards(AuthGuard)
@ApiBearerAuth()
@Controller('state')
export class StateController {
  constructor(private readonly stateServices: StateService) {}

  @Get()
  getStateList() {
    return this.stateServices.getStates();
  }

  @Get(':id')
  @ApiParam({ example: '594ced02ed345b2b049222c5', name: 'id' })
  findById(@Param() { id }: idDto) {
    return this.stateServices.getStatesWithCities({ _id: id });
  }
}
