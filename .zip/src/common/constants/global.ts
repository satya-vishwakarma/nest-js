export const CONSTS = {
  ADDITIONAL_FEATURE: [
    'Life Skills',
    'Professional Development',
    'Assessments',
    'Toolkit',
    'Data + Reporting',
  ],
  PROGRAMS: ['Career Services', 'Curriculum', 'Integrations'],
  ADMIN_USER_ROLE: '644f4c8e45f2a92340d2e121',
  USER_REG_CONFIRM: 'User registration confirmed successfully!',
  SUCCESS_OTP: 'successfully sent otp to',
  CHANGE_PASSWORD: 'password has been changed successfully',

  PROGRAMS_JSON: [
    { id: 'career_services', name: 'Career Services', isChecked: false },
    { id: 'curriculum', name: 'Curriculum', isChecked: true },
    { id: 'integrations', name: 'Integrations', isChecked: false },
  ],

  ADDITIONAL_FEATURE_JSON: [
    { id: 'life_skills', name: 'Life Skills', isChecked: false },
    {
      id: 'professional_development',
      name: 'Professional Development',
      isChecked: false,
    },
    { id: 'assessments', name: 'Assessments', isChecked: false },
    { id: 'toolkit', name: 'Toolkit', isChecked: false },
    { id: 'data_reporting', name: 'Data + Reporting', isChecked: true },
  ],
};
