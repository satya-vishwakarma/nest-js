import cfg from './../config/config';

export const initAws = (aswConfig) => {
  aswConfig.update({
    accessKeyId: cfg().AWS_ACCESS_KEY_ID,
    secretAccessKey: cfg().AWS_SECRET_ACCESS_KEY,
    region: cfg().AWS_REGION,
  });
};
