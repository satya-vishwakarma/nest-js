import { INestApplication } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import cfg from './../config/config';

export const initSwagger = (app: INestApplication) => {
  if (cfg().nodeEnv != 'development') return;
  const swaggerCfg = new DocumentBuilder()
    .setTitle('Multi tenants ')
    .setDescription('Multi tenants APIs document')
    .setVersion('1.0')
    .addTag('Tenant')
    .addBearerAuth({
      name: 'Authorization',
      bearerFormat: 'Bearer',
      scheme: 'Bearer',
      type: 'http',
      in: 'Header',
    })
    .addServer('http://localhost:3050', 'Local APIs')
    .addServer('http://localhost:3051', 'Dev APIs')
    .build();
  const document = SwaggerModule.createDocument(app, swaggerCfg);
  SwaggerModule.setup('api-docs', app, document);
};
