import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';

import { ConfigService } from '@nestjs/config';
import { authStub } from './stubs/auth.stub';
const crypto = require('crypto');

const hashMock = {
  update: jest.fn().mockReturnThis(),
  digest: jest.fn().mockReturnValueOnce('encrypt 123'),
};
const createHashMock = jest
  .spyOn(crypto, 'createHash')
  .mockImplementationOnce(() => hashMock);

jest.mock('@aws-sdk/client-cognito-identity-provider', () => {
  return {
    CognitoIdentityProvider: class {
      adminAddUserToGroup() {
        return Promise.resolve();
      }
      initiateAuth() {
        return Promise.resolve({ token: 'Abc' });
      }
      confirmSignUp() {
        return Promise.resolve(true);
      }
      signUp() {
        return Promise.resolve();
      }
      confirmForgotPassword() {
        return Promise.resolve();
      }

      forgotPassword() {
        return Promise.resolve();
      }
    },
  };
});

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn().mockImplementation((item) => {
              const envs = {
                AWS_SECRET_HASH: 'abc',
                AWS_USER_POOL_ID: 'abc',
              };
              return envs[item];
            }),
          },
        },
        AuthService,
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
  });

  afterEach(() => {
    createHashMock.mockClear();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should be call signUpUser method', async () => {
    const mock = jest
      .spyOn(service, 'addUserToGrp')
      .mockImplementationOnce(() => {
        return Promise.resolve(true);
      });

    const result = await service.signUpUser(authStub);

    expect(result).toBeTruthy();
    mock.mockClear();
  });
  it('should be call confirmSignUp method', async () => {
    const result = await service.confirmSignUp(authStub, '1234');
    expect(result).toBeTruthy();
  });
  it('should be call forgotPassword method', async () => {
    const result = await service.forgotPassword(authStub.email);
    expect(result).toBeTruthy();
  });
  it('should be call confirmNewPassword method', async () => {
    const result = await service.confirmNewPassword(
      authStub.email,
      authStub.password,
      '123',
    );
    expect(result).toBeTruthy();
  });

  it('should be call signInUser method', async () => {
    const result: any = await service.signInUser(
      authStub.email,
      authStub.password,
    );

    expect(result.token).toBe('Abc');
  });
});
