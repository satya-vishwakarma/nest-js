export const authStub = {
  firstName: 'abc',
  lastName: 'abc',
  email: 'tesqt23321@yopmail.com',
  password: 'Test@12344',
  phonenumber: '+15555555555',
  zipcode: 13233,
  roles: '1',
  ssn: '',
  status: 1,
  createdBy: '',
  createdAt: undefined,
  lastLoggedIn: undefined,
};
