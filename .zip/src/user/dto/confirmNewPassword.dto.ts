import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class confirmNewPasswordDto {
  @ApiProperty({
    example: 'abc@yopmail.com',
    description: 'user name',
  })
  @IsNotEmpty()
  readonly username: string;

  @ApiProperty({
    example: 'Avx@212',
    description: 'Password',
  })
  @IsNotEmpty()
  readonly password: string;

  @ApiProperty({
    example: '1234',
    description: 'Code',
  })
  @IsNotEmpty()
  readonly code: string;
}
