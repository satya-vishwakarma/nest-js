import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class forgotPasswordDto {
  @ApiProperty({
    example: 'abc@yopmail.com',
    description: 'Email Id',
  })
  @IsNotEmpty()
  readonly email: string;
}
