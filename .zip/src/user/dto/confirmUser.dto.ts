import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ConfirmUserDto {
  @ApiProperty({
    example: 'abc@yopmail.com',
    description: 'Email Id',
  })
  @IsNotEmpty()
  readonly email: string;

  @ApiProperty({
    example: '1234',
    description: 'code',
  })
  @IsNotEmpty()
  readonly code: string;
}
