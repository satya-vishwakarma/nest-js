import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class LoginUserDto {
  @ApiProperty({
    example: 'test23321@yopmail.com',
    description: 'Email id',
  })
  @IsNotEmpty()
  readonly email: string;

  @ApiProperty({
    example: 'Samsung@123',
    description: 'Password',
  })
  @IsNotEmpty()
  readonly password: string;
}
