import { IsEmail, IsNotEmpty, Matches } from 'class-validator';
import { BaseUserDto } from './baseUser.dto';

import { ERROR } from './../../common/constants/';
import { ApiProperty } from '@nestjs/swagger';
const { PASSWORD_WEAK } = ERROR;

export class CreateUserDto extends BaseUserDto {
  @ApiProperty({
    example: 'abc',
    description: 'firstName',
  })
  @IsNotEmpty()
  firstName: string;

  @ApiProperty({
    example: 'abc',
    description: 'last Name',
  })
  @IsNotEmpty()
  lastName: string;

  @ApiProperty({
    example: 'abc@yopmail.com',
    description: 'Email Id',
  })
  @IsNotEmpty()
  @IsEmail()
  email: string;

  @ApiProperty({
    example: 'Abc@123',
    description: 'Password',
  })
  @IsNotEmpty()
  @Matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/, {
    message: PASSWORD_WEAK,
  })
  password: string;

  @ApiProperty({
    example: '+1555555555',
    description: 'Phone number',
  })
  @IsNotEmpty()
  phonenumber: string;

  @ApiProperty({
    example: '1223',
    description: 'Zip code',
  })
  @IsNotEmpty()
  zipcode: number;
}
