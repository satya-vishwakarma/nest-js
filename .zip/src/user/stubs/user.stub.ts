export const userStub = {
  firstName: 'abc',
  lastName: 'abc',
  email: 'eee@yopmail.com',
  password: 'AVC@12344',
  phonenumber: '+15555555555',
  zipcode: 13233,
};
