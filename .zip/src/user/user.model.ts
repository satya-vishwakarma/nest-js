import { AuthService } from './../auth/auth.service';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { User } from '../schemas/';
import { BaseModel } from '../common/models/baseModel';
import { CreateUserDto } from './dto/createUser.dto';
import { ERROR } from '../common/constants';
import { isEmptyObj } from '../common/helpers/helper';

@Injectable()
export class UserModel extends BaseModel {
  constructor(
    @InjectModel(User.name)
    private readonly userModel: Model<User>,
    private readonly authService: AuthService,
  ) {
    super(userModel);
  }
  async create(createUserDto: CreateUserDto) {
    try {
      /*
       * Checking user is already exists or Not
       */
      const userExists = await this.findOne({ email: createUserDto.email });
      if (!isEmptyObj(userExists)) {
        throw new ForbiddenException(ERROR.USER_EXISTS);
      }
      await this.authService.signUpUser(createUserDto);

      createUserDto.password = this.authService.hashSecret(createUserDto.email);
      const saveResult = await this.save(createUserDto);
      const resultSet = { ...saveResult._doc };
      delete resultSet.password;

      return resultSet;
    } catch (error) {
      Logger.log(error);
      throw new InternalServerErrorException(error.response);
    }
  }
}
