import { Test, TestingModule } from '@nestjs/testing';
import { UserService } from './user.service';
import { UserModel } from './user.model';
import { AuthService } from '../auth/auth.service';
import { userStub } from './stubs/user.stub';

describe('UserService', () => {
  let service: UserService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        {
          provide: UserModel,
          useValue: {
            create: jest.fn().mockImplementation(() => {
              return userStub;
            }),
            findOne: jest.fn().mockImplementation(() => {
              return { userStub };
            }),
          },
        },
        {
          provide: AuthService,
          useValue: {
            confirmSignUp: jest.fn().mockImplementation(() => {
              return true;
            }),
            signInUser: jest.fn().mockImplementation(() => {
              return {
                AuthenticationResult: {
                  AccessToken: 'abc',
                },
              };
            }),
            forgotPassword: jest.fn().mockImplementation(() => {
              return true;
            }),
          },
        },
        UserService,
      ],
    }).compile();

    service = module.get<UserService>(UserService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should be call createUser method', async () => {
    const result: any = await service.createUser(userStub);
    expect(result.email).toBe('eee@yopmail.com');
  });

  it('should be call confirmSignUp method', async () => {
    const result: any = await service.confirmSignUp({
      email: userStub.email,
      code: '123',
    });
    expect(result).toBe('User registration confirmed successfully!');
  });
  it('should be call loginUser method', async () => {
    const result: any = await service.loginUser({
      email: userStub.email,
      password: userStub.password,
    });
    expect(result.accessToken).toBe('abc');
  });

  it('should be call forgotPassword method', async () => {
    const result: any = await service.forgotPassword({
      email: userStub.email,
    });
    expect(result).toBe(`successfully sent otp to ${userStub.email}`);
  });
});
