import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { userStatus } from '../common/enums';

export type StateDocument = HydratedDocument<State>;

@Schema({ collection: 'states' })
export class State {
  _id: string;

  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  code: string;

  @Prop({ default: userStatus['ACTIVE'] })
  status: string;
}

export const StateSchema = SchemaFactory.createForClass(State);
