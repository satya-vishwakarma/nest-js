import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { userStatus } from '../common/enums';

export type TimeZoneDocument = HydratedDocument<TimeZone>;

@Schema({ collection: 'timezone' })
export class TimeZone {
  _id: string;
  @Prop({ required: true })
  'name': string;

  @Prop({ required: true })
  'value': string;

  @Prop({ default: userStatus['ACTIVE'] })
  status: string;
}

export const TimeZoneSchema = SchemaFactory.createForClass(TimeZone);
