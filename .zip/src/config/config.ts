export default () => ({
  port: process.env.API_PORT,
  mongodb: {
    connectionString: process.env.MONGODB_CONNECTION_STRING,
    dbName: process.env.MONGODB_DB_NAME,
  },
  enableDebugMessage: process.env.ENABLE_DEBUG_MSGS || false,
  nodeEnv: process.env.NODE_ENV || 'development',
  AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID,
  AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY,
  AWS_REGION: process.env.AWS_REGION,
});
